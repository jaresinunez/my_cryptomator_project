//
//  CryptomatorFileProvider.h
//  CryptomatorFileProvider
//
//  Created by Philipp Schmid on 24.06.20.
//  Copyright © 2020 Skymatic GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for CryptomatorFileProvider.
FOUNDATION_EXPORT double CryptomatorFileProviderVersionNumber;

//! Project version string for CryptomatorFileProvider.
FOUNDATION_EXPORT const unsigned char CryptomatorFileProviderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CryptomatorFileProvider/PublicHeader.h>
