//
//  FolderCreationTask.swift
//  CryptomatorFileProvider
//
//  Created by Philipp Schmid on 07.06.21.
//  Copyright © 2021 Skymatic GmbH. All rights reserved.
//

import Foundation

struct FolderCreationTask: CloudTask {
	let itemMetadata: ItemMetadata
}
