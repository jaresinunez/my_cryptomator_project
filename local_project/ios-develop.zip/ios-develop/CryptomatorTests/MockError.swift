//
//  MockError.swift
//  CryptomatorTests
//
//  Created by Philipp Schmid on 29.06.21.
//  Copyright © 2021 Skymatic GmbH. All rights reserved.
//

import Foundation

enum MockError: Error {
	case notMocked
}
