public enum HubSubscriptionState: String, Codable {
	case active
	case inactive
}
